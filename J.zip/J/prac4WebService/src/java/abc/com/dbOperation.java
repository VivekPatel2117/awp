package abc.com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.sql.DataSource;

/**
 * @author Sakshi
 */
@WebService(serviceName = "message")
public class dbOperation {

    @Resource(name = "mydsn")
    private DataSource mydsn;

    /**
     * One-Way Web service operation (no return type)
     */
    @WebMethod(operationName = "insertName")
    @Oneway
    public void insertName(@WebParam(name = "id") int id,
                           @WebParam(name = "name") String name) {
        String sql = "INSERT INTO APP.STUDENT (ID, NAME) VALUES (?, ?)";
        try (Connection c = mydsn.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.setString(2, name);
            ps.executeUpdate();

            System.out.println("✅ Inserted student: " + id + " - " + name);

        } catch (SQLException e) {
            e.printStackTrace(); // You could also log to server logs
        }
    }

    /**
     * Request-Response Web service operation
     */
    @WebMethod(operationName = "getName")
    public String getName(@WebParam(name = "ID") int ID) {
        String sql = "SELECT NAME FROM APP.STUDENT WHERE ID = ?";
        try (Connection c = mydsn.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, ID);
            try (ResultSet r = ps.executeQuery()) {
                if (r.next()) {
                    return r.getString("NAME");
                } else {
                    return "No name found for ID " + ID;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return "❌ Error: " + e.getMessage();
        }
    }

    /**
     * Debug helper: list all tables visible to this connection.
     */
    @WebMethod(operationName = "listTables")
    public String listTables() {
        StringBuilder sb = new StringBuilder();
        try (Connection c = mydsn.getConnection();
             ResultSet rs = c.getMetaData().getTables(null, null, "%", new String[]{"TABLE"})) {

            while (rs.next()) {
                sb.append(rs.getString("TABLE_SCHEM"))
                  .append(".")
                  .append(rs.getString("TABLE_NAME"))
                  .append("\n");
            }
        } catch (SQLException e) {
            return "❌ Error: " + e.getMessage();
        }
        return sb.toString();
    }
}
