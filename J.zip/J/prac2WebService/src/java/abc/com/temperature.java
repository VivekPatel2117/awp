/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.com;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author heshi
 */
@WebService(serviceName = "temperature")
public class temperature {

    /**
     * This is a sample web service operation
     */
   @WebMethod(operationName = "celsiusToFahrenheit")
public Double celsiusToFahrenheit(@WebParam(name = "celsius") Double celsius) {
    return (celsius * 9 / 5) + 32;
}

@WebMethod(operationName = "fahrenheitToCelsius")
public Double fahrenheitToCelsius(@WebParam(name = "fahrenheit") Double fahrenheit) {
    return (fahrenheit - 32) * 5 / 9;
}

}
