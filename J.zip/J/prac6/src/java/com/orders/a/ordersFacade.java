/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.orders.a;

import com.orders.orders;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author heshi
 */
@Stateless
public class ordersFacade extends AbstractFacade<orders> {
    @PersistenceContext(unitName = "prac6PU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ordersFacade() {
        super(orders.class);
    }
    
}
