/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.orders;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author heshi
 */
@Entity
@XmlRootElement
public class orders implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String delivery_status;

    /**
     * Get the value of delivery_status
     *
     * @return the value of delivery_status
     */
    public String getDelivery_status() {
        return delivery_status;
    }

    /**
     * Set the value of delivery_status
     *
     * @param delivery_status new value of delivery_status
     */
    public void setDelivery_status(String delivery_status) {
        this.delivery_status = delivery_status;
    }

    private String product_name;

    /**
     * Get the value of product_name
     *
     * @return the value of product_name
     */
    public String getProduct_name() {
        return product_name;
    }

    /**
     * Set the value of product_name
     *
     * @param product_name new value of product_name
     */
    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    private String customer_name;

    /**
     * Get the value of customer_name
     *
     * @return the value of customer_name
     */
    public String getCustomer_name() {
        return customer_name;
    }

    /**
     * Set the value of customer_name
     *
     * @param customer_name new value of customer_name
     */
    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof orders)) {
            return false;
        }
        orders other = (orders) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.orders.orders[ id=" + id + " ]";
    }
    
}
