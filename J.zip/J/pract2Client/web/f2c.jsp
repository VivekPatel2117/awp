    <%-- start web service invocation --%><hr/>
    <%
    try {
	abc.com.Temperature_Service service = new abc.com.Temperature_Service();
	abc.com.Temperature port = service.getTemperaturePort();
	 // TODO initialize WS operation arguments here
        Double d = Double.parseDouble(request.getParameter("temp"));
	java.lang.Double fahrenheit = d ;
	// TODO process result here
	java.lang.Double result = port.fahrenheitToCelsius(fahrenheit);
	out.println("Result = "+result);
    } catch (Exception ex) {
	// TODO handle custom exceptions here
    }
    %>
    <%-- end web service invocation --%><hr/>
