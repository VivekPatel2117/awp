/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.com;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author heshi
 */
@WebService(serviceName = "weather")
public class weather {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "weatherInfo")
    public String weatherInfo(@WebParam(name = "city") String city) {
        if (city.equals("Navi Mumbai")) {
            return "Heavy Rainfall";
        } else if (city.equals("Mumbai")) {
            return "No rainfall";
        } else {
            return "No information found for" + city;
        }
    }
}
