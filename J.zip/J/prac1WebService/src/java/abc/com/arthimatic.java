/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.com;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author heshi
 */
@WebService(serviceName = "arthimatic")
public class arthimatic {

    /**
     * Addition
     */
    @WebMethod(operationName = "add")
    public Integer add(@WebParam(name = "num1") Integer num1,
                       @WebParam(name = "num2") Integer num2) {
        return num1 + num2;
    }

    /**
     * Subtraction
     */
    @WebMethod(operationName = "subtract")
    public Integer subtract(@WebParam(name = "num1") Integer num1,
                            @WebParam(name = "num2") Integer num2) {
        return num1 - num2;
    }

    /**
     * Multiplication
     */
    @WebMethod(operationName = "multiply")
    public Integer multiply(@WebParam(name = "num1") Integer num1,
                            @WebParam(name = "num2") Integer num2) {
        return num1 * num2;
    }

    /**
     * Division
     */
    @WebMethod(operationName = "divide")
    public Double divide(@WebParam(name = "num1") Integer num1,
                         @WebParam(name = "num2") Integer num2) {
       
        return (double) num1 / num2;
    }
}
