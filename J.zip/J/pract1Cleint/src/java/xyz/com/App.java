/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xyz.com;
import java.util.Scanner;
/**
 *
 * @author heshi
 */
public class App {

    private static Integer add(java.lang.Integer num1, java.lang.Integer num2) {
        abc.com.Arthimatic_Service service = new abc.com.Arthimatic_Service();
        abc.com.Arthimatic port = service.getArthimaticPort();
        return port.add(num1, num2);
    }

    private static Double divide(java.lang.Integer num1, java.lang.Integer num2) {
        abc.com.Arthimatic_Service service = new abc.com.Arthimatic_Service();
        abc.com.Arthimatic port = service.getArthimaticPort();
        return port.divide(num1, num2);
    }

    private static Integer multiply(java.lang.Integer num1, java.lang.Integer num2) {
        abc.com.Arthimatic_Service service = new abc.com.Arthimatic_Service();
        abc.com.Arthimatic port = service.getArthimaticPort();
        return port.multiply(num1, num2);
    }

    private static Integer subtract(java.lang.Integer num1, java.lang.Integer num2) {
        abc.com.Arthimatic_Service service = new abc.com.Arthimatic_Service();
        abc.com.Arthimatic port = service.getArthimaticPort();
        return port.subtract(num1, num2);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter first number: ");
        int num1 = sc.nextInt();

        System.out.println("Enter second number: ");
        int num2 = sc.nextInt();

        System.out.println("Addition Result: " + add(num1, num2));
        System.out.println("Subtraction Result: " + subtract(num1, num2));
        System.out.println("Multiplication Result: " + multiply(num1, num2));

        System.out.println("Division Result: " + divide(num1, num2));

        sc.close();
    }
}
